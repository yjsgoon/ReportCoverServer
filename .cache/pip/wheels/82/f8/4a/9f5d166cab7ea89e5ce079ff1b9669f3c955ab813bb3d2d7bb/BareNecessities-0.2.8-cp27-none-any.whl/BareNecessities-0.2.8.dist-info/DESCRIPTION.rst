BareNecessities
+++++++++++++++

.. contents ::

Summary
=======

Provides the ``bn`` module containing a dictionary allowing attribute access to
values - I use it so much I've made into a package.

Get Started
===========

* Download and install from source or from the egg provided.

Author
======

`James Gardner <http://jimmyg.org>`_


Changes
=======

0.2.8
-----

2011-04-12
~~~~~~~~~~

* Added ``OrderedDict`` and ``MarbleLike``

0.2.7
-----

2010-10-13
~~~~~~~~~~

* Moved the nesting capability of ``AttributeDict`` to
  ``NestedAttributeDict``.

0.2.6
-----

2010-08-24
~~~~~~~~~~

* Added ``day_of_month_in_english()`` function.

0.2.5
-----

2010-01-23
~~~~~~~~~~

* Upgraded ``AttributeDict()`` to support setting nested keys.

0.2.4
-----

2009-12-10
~~~~~~~~~~

* Bumped the version number and updated the ``setup.py`` and ``MANIFEST.in`` 
  files.

0.2.3
-----

2009-10-20
~~~~~~~~~~

* Added support for ``HTMLFragment``

0.2.2
-----

2009-10-04
~~~~~~~~~~

* Updated ``MANIFEST.in`` to include the docs and tests

2009-10-03
~~~~~~~~~~

* Using a plain ``__import__()`` now without trying to deduce why any
  ``ImportError`` occurs

0.2.1
-----

2009-08-25
~~~~~~~~~~

* Fixed the relative import to use ``__import__()`` instead of imp where
  a bug (or my misunderstanding) was causing modules which couldn't be 
  imported to get the namespace of other modules with the same name
  causing havoc!
* Added the ability to import the root package.

2009-08-20
~~~~~~~~~~

* Added the ``str_dict()`` function to change Unicode dict keys to strings

0.2
---

2009-07-17
~~~~~~~~~~

* Added a set of import tools for relative and absolute imports at runtime
  even within scripts and with versions of Python prior to 2.5.
* Added missing ``posixpath`` import.
* Changed ``AttributeDict`` to raise an ``AttributeError`` when setting a
  non-existent key instead of a ``NotImplementedError``.

2009-06-13
~~~~~~~~~~

* Added ``uniform_path()`` function
* Added begining of code for import related functions, including relative 
  imports within scripts (Python 2.5 only supports relative imports within
  packages)
* Added ``relpath()``, a function to calculate the relative path between two
  locations (only works on POSIX systems and already exists in Python 2.6)

0.1.0
-----

2009-07-04
~~~~~~~~~~

* Added the AttributeDict


License
=======
Copyright (C) 2009 James Gardner - http://jimmyg.org/

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


Download
========


