Mail
++++

.. contents :: 

Summary
=======

Simple wrapper over Python's email package for common operations.

Get Started
===========

* Download and install from source

Author
======

`James Gardner <http://jimmyg.org>`_


Changes
=======

2.1.0
-----

2010-09-02
~~~~~~~~~~

* Support for PipeStack
* Better documentation and examples
* Fixed a bug when using an SMTP port
* Moved all the helper functions from ``mail`` to ``mail.helper``. For legacy
  code all references to ``mail`` will need to be replaced with
  ``mail.helper``.

2.0.2
-----

2009-12-24
~~~~~~~~~~

* Added support for STARTTLS

2.0.1
-----

2009-10-04
~~~~~~~~~~

* First version

License
=======
Mail - Simple wrapper over Python's email package for common operations.
Copyright (C) 2009 James Gardner

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Download
========


